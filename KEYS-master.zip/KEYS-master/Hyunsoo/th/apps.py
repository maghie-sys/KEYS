from django.apps import AppConfig


class ThConfig(AppConfig):
    name = 'th'
